/**
 * Clase Mascota
 */
package entidades;

import java.sql.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author juanj
 */
public class Mascota {   
    private String microchip;
    private String nombre;
    private Date fecha_nacimiento;
    private String raza;
    private Especie especie;
    
    /**
     * Clase Enum para saber el tipo de Especie de la Mascota
     */
    public enum Especie {
        PERRO(1),
        GATO(2),
        CONEJO(3);

        private int id_especie = 1;

        Especie(int nombre) {
                this.id_especie = nombre;
        }

        public int getIdEspecie() {
            return id_especie;
        }
    }
    /**
     * Constructor de la clase
     * @param microchip
     * @param nombre
     * @param fecha_nacimiento YYYY/MM/DD
     * @param raza
     * @param especie 
     */
    public Mascota(String microchip, String nombre, Date fecha_nacimiento, String raza, Especie especie) {
            this.microchip = microchip;
            this.nombre = nombre;
            this.fecha_nacimiento = fecha_nacimiento;
            this.raza = raza;
            this.especie = especie;
 
    }
    
    /**
     * Getter del microchip 
     * @return 
     */
    public String getMicrochip() {
        return microchip;
    }
    /**
     * Getter de la Especie
     * @return 
     */
    public Especie getEspecie() {
        return especie;
    }
    /**
     * Getter de la raza
     * @return 
     */
    public String getRaza() {
        return raza;
    }
    /**
     * Getter del nombre
     * @return 
     */
    public String getNombre() {
        return nombre;
    }

    public Date getFecha_nacimiento() {
        return fecha_nacimiento;
    }
     
    /**
     * Setter del nombre por si se le cambia
     * @param nombre 
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        String especie = "";
        switch(this.especie.getIdEspecie()){
            case 1 -> especie = "Perro";
            case 2 -> especie = "Gato";
            case 3 -> especie = "Conejo";              
        }
        String res = "El " + especie + ", llamado " + nombre + "\n"
                + ", de raza: " + raza + " , nacido "  + fecha_nacimiento;
        return res;   
    }
    
    
  
}

