/**
 * Clase DAO de Cliente
 */
package entidadesDAO;

import entidades.Cliente;
import entidades.Mascota;
import entidades.Mascota.Especie;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author juanj
 */
public class ClienteDAO {
    
    Cliente c1;
    
    /**
     * Constructo de la clase vacio para inicializarla
     */
    public ClienteDAO(Cliente client){
        this.c1 = client;
    }
    /**
     * 
     * @param contraseña 
     */
    public void insertarCliente(String contraseña){
    try{
        Connection conn = conectarBD.conectarBD();
        String sql = "INSERT INTO CLIENTE(USUARIO, CONTRASEÑA, DNI, NOMBRE, TELF, DIRECCION)\n"
                + "VALUES(?,?,?,?,?,?)";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, c1.getUsuario());
        stmt.setString(2, contraseña);
        stmt.setString(3, c1.getDNI());
        stmt.setString(4, c1.getNombre());
        stmt.setString(5, c1.getTelf());
        stmt.setString(6, c1.getDireccion());
        
        int filas = stmt.executeUpdate();
        System.out.println("Filas insertadas: " + filas);
        conectarBD.desconectarBD(conn);
    }catch(SQLException e){
        System.out.println("Error cliente insercion: " + e.getMessage());
    }
    }
    /**
     * Metodo que elimina a un cliente de la base de datos con borrado logico
     * @param usuario 
     */
    public void eliminarCliente(){
        try{
            Connection conn = conectarBD.conectarBD();
            String sql = "UPDATE CLIENTE\n"
                    + "SET ES_ACTIVO = 0\n"
                    + "WHERE USUARIO = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, c1.getUsuario());
            
            int filas = stmt.executeUpdate();
            System.out.println("Filas actualizadas: " + filas);
            conectarBD.desconectarBD(conn);
        }catch(SQLException e){
            System.out.println("Error cliente eliminacion: " + e.getMessage());
        }
    }
    
    public void rellenarListaMascotas(List lista){
        try{
            Connection conn = conectarBD.conectarBD();
            PreparedStatement stmt = conn.prepareStatement("SELECT MASCOTA.* FROM CLIENTE INNER JOIN cliente_posee_mascota ON\n" +
                                                           "cliente.usuario=cliente_posee_mascota.id_cliente\n" +
                                                           "inner join Mascota on\n" +
                                                           "cliente_posee_mascota.id_mascota=mascota.numero_microchip\n" +
                                                           "where cliente.usuario=? ");
            stmt.setString(1, c1.getUsuario());
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                int id = rs.getInt("ID_ESPECIE");
                Especie especie = null;
                switch(id){
                    case 1 -> especie = Especie.PERRO;
                    case 2 -> especie = Especie.GATO;
                    case 3 -> especie = Especie.CONEJO;              
                }
                Mascota m1 = new Mascota(rs.getString("NUMERO_MICROCHIP"), rs.getString("NOMBRE"), rs.getDate("FECHA_NACIMIENTO"), rs.getString("RAZA"), especie);
                lista.add(m1);
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
}
