/**
 * Clase Trabajador heredada de Usuario
 */
package entidades;

import java.sql.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author juanj
 */
public class Trabajador extends Usuario{
    
    Date fecha;
    
    /**
     * Constructor de la clase
     * @param usuario
     * @param nombre 
     */
    public Trabajador(String usuario, String nombre, String DNI, Date fecha) {
        super(usuario, nombre, DNI);
        this.fecha = fecha;
    }

    /**
     * Metodo toString 
     * @return 
     */
   
}
