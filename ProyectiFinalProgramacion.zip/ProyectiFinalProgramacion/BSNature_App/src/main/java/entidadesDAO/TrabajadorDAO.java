/**
 * Clase DAO de Trabajador
 */
package entidadesDAO;

import entidades.Admin;
import entidades.Trabajador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author juanj
 */
public class TrabajadorDAO {
    
    private Trabajador t1;
    
    /**
     * Constructor que toma una entidad de clase Admin
     * @param admin 
     */
    public TrabajadorDAO(Trabajador admin){
        this.t1 = admin;
    }
    
    /**
     * Funcion que inserta Trabajadores en la base de datos
     * @param usuario
     * @param contraseña
     * @param DNI
     * @param nombre
     * @return numero de filas que se han insertado normamelte uno
     */
    public int insertarTrabajador(String contrasena){
        int filas = 0;
        try {          
                Connection conn = conectarBD.conectarBD();
                System.out.println("Despues de conectarse");
                String sql = "INSERT INTO TRABAJADOR (USUARIO, CONTRASEÑA, DNI, NOMBRE, FECHA_CONTRATACION) " + "\n"
                        + "VALUES (?, ?, ?, ?, sysdate)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                System.out.println("antes de ejecutarla");
                stmt.setString(1, t1.getUsuario());
                stmt.setString(2, contrasena);
                stmt.setString(3, t1.getDNI());
                stmt.setString(4, t1.getNombre());
                filas = stmt.executeUpdate();
                System.out.println("Filas insertadas : " + filas);
                
                /*System.out.println(filas + " filas insertadas");*/
                conectarBD.desconectarBD(conn);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Ha habido un error, habras puesto un trabajador no activo");
            }
        
        return filas;
    }
    /**
     * Funcion que otorga el valor inactivo en la base de datos conocido como borrado logico
     * @param usuario
     * @return devuelve el numero de filas eliminadas normamelte 1
     */
    public int eliminarTrabajador(){
        int filas = 0;
        try{
            Connection conn = conectarBD.conectarBD();
            String sql = "UPDATE TRABAJADOR\n"
                    + "SET ES_ACTIVO = 0\n"
                    + "WHERE USUARIO = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            System.out.println("Hola");
            stmt.setString(1, t1.getUsuario());
            
            filas = stmt.executeUpdate();
            
            System.out.println(filas + " filas eliminadas");
            conectarBD.desconectarBD(conn);
        }catch(SQLException e){
            System.out.println("Error eliminacion: " + e.getMessage());
        }
        return filas;
    }
    
    
}
