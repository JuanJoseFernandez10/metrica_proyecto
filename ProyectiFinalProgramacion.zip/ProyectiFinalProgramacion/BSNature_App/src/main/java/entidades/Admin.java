/**
 * Clase admin heredada de Usuario
 */
package entidades;

import java.sql.Date;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author juanj
 */
public class Admin extends Usuario{
    
    Date fecha;
    
    
    /**
     * Constructor de la clase
     * @param usuario
     * @param nombre 
     */
    public Admin(String usuario, String nombre, String DNI, Date fecha) {
        super(usuario, nombre, DNI);
       

        this.fecha = fecha;
    }
   
    
    
}
