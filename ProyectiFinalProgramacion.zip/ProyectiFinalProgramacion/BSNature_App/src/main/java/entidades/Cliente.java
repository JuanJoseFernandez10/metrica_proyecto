/**
 * Clase Cliente heredada de Usuario
 */
package entidades;

import entidadesDAO.ClienteDAO;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author juanj
 */
public class Cliente extends Usuario{
    
    String telf;
    String direccion;
    List mascotas = new ArrayList();
    
    /**
     * Constructor de la clase
     * @param usuario
     * @param nombre 
     */
    public Cliente(String usuario, String nombre, String DNI, String telf, String direccion) {
        super(usuario, nombre, DNI);
        
            this.telf = telf;
            this.direccion = direccion;
            rellenarLista(mascotas);
       
    }
    
    public List getLista(){
        mascotas.clear();
        rellenarLista(mascotas);
        return this.mascotas;
    }
    
    private void rellenarLista(List lista){
        Comparator<Mascota> comparador = new Comparator<Mascota>() {
            @Override
            public int compare(Mascota m1, Mascota m2) {
                return (m1.getFecha_nacimiento().compareTo(m2.getFecha_nacimiento()));
            }
        };
        ClienteDAO c1 = new ClienteDAO(this);
        c1.rellenarListaMascotas(lista);
        lista.sort(comparador);
        
    }

    public String getTelf() {
        return telf;
    }

    public String getDireccion() {
        return direccion;
    }
    
    
    
    
}
