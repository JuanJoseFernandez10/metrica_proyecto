/**
 * Clase Abstracta Usuario
 */
package entidades;

import javax.swing.JOptionPane;

/**
 *
 * @author juanj
 */
public abstract class Usuario {
    
    private String usuario;
    private String nombre;
    private String DNI;
    /**
     * Contructor de la clase abstracta
     * @param usuario
     * @param nombre 
     */
    public Usuario(String usuario, String nombre, String DNI){
        
        this.usuario = usuario;
        this.nombre = nombre;
        this.DNI = DNI;
        
    }
    /**
     * Getter de usuario
     * @return nombre del usuario
     */
    public String getUsuario() {
        return usuario;
    }
    /**
     * Setter de usuario
     * @param usuario 
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    /**
     * Getter de nombre
     * @return nombre de la persona
     */
    public String getNombre() {
        return nombre;
    }
    /**
     * Setter de nombre
     * @param nombre 
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }
    
    
    /**
     * Metodo abstracto de toString para asegurar sun implementacion
     * @return 
     */
    @Override
    public String toString(){
         return getNombre() + ", usuario: " + getUsuario() + " DNI: " + getDNI();
    }
}
